self.__precacheManifest = [
  {
    "revision": "ee310b01163bc4cdddc2",
    "url": "/static/css/main.9e27d727.chunk.css"
  },
  {
    "revision": "ee310b01163bc4cdddc2",
    "url": "/static/js/main.f409ea8d.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "827a727f91d27386edfe",
    "url": "/static/js/2.9d196b4d.chunk.js"
  },
  {
    "revision": "3890bd9c7c78f4a6eb29c39b6a55ec0b",
    "url": "/static/media/user.3890bd9c.svg"
  },
  {
    "revision": "84a7ecf511b1a43c2458bd2c033df8b4",
    "url": "/static/media/price-tag.84a7ecf5.svg"
  },
  {
    "revision": "c9a61e5e5a4037844798863446d357d2",
    "url": "/static/media/auth_boy.c9a61e5e.png"
  },
  {
    "revision": "a58eb9f1f35892828dbb4a584042ef37",
    "url": "/static/media/T-shirt1.a58eb9f1.png"
  },
  {
    "revision": "c6f46673e2449eb071e2c098c5190c2a",
    "url": "/static/media/IRANSansWeb.c6f46673.woff2"
  },
  {
    "revision": "df14582918ca379a280e453bb3cc6ba5",
    "url": "/static/media/IRANSansWeb.df145829.woff"
  },
  {
    "revision": "ac22d187130d6c3433a49a1e98bfa968",
    "url": "/static/media/IRANSansWeb.ac22d187.ttf"
  },
  {
    "revision": "e43cfbc1a67d90e910398ded8345cd32",
    "url": "/static/media/IRANSansWeb.e43cfbc1.eot"
  },
  {
    "revision": "1d75adeb1f4a1495ec292bbbb7daa57a",
    "url": "/static/media/kid5.1d75adeb.png"
  },
  {
    "revision": "c0f09632479162cf4268a655645bbab0",
    "url": "/static/media/girl.c0f09632.png"
  },
  {
    "revision": "733773cb37091f370aca5363c9865fee",
    "url": "/index.html"
  }
];